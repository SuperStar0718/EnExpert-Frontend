import Navbar from "./Navbar";
import NavMobile from "./NavMobile";

const index = () => {
  return (
    <div>
      <Navbar />
      <NavMobile />
    </div>
  );
};

export default index;
