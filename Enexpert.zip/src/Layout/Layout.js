import React, { useState } from "react";

import {
  Layout,
  Menu,
  Dropdown,
  Button,
  Input,
  Select,
  Badge,
  Avatar,
  Switch,
} from "antd";
import { MdOutlineLightMode, MdLightMode } from "react-icons/md";
import {
  CloseOutlined,
  LogoutOutlined,
  BellOutlined,
  SettingOutlined,
  SearchOutlined,
} from "@ant-design/icons";
import { useHistory } from "react-router";
import { useDispatch } from "react-redux";
import MainMenu from "./MainMenu";
import { changeValue } from "../redux";
import logo from "../Assets/logo.PNG";
import { FaAngleDown } from "react-icons/fa";

const VerticalLayout = ({ children, active }) => {
  const { Header, Sider, Content, Footer } = Layout;
  const history = useHistory();
  const dispatch = useDispatch();

  const mode = JSON.parse(localStorage.getItem("themeConfig"))?.mode;
  const adminName = localStorage.getItem("name");

  return (
    <div className="v-layout">
      <Layout>
        <Sider
          style={{
            height: "auto",
            borderRight: "1px solid var(--secondary)",
          }}
        >
          <div className="logo">
            <img src={logo} />
          </div>

          <MainMenu active={active} />
        </Sider>
        <Layout className="site-layout">
          <Header style={{ padding: 0 }} className="layout-header">
            <div className="header-row">
              <div className="search-bar">
                <Input placeholder="search..." prefix={<SearchOutlined />} />
              </div>
              <div className="header-right">
                <Badge count={4}>
                  <Avatar
                    icon={<BellOutlined />}
                    style={{ color: "var(--text)", background: "transparent" }}
                  />
                </Badge>
                <div style={{ display: "flex", alignItems: "center" }}>
                  {/* <span>Admin</span> */}
                  <Badge dot>
                    <Avatar src="https://joeschmoe.io/api/v1/random" />
                  </Badge>
                  <span className="name">Melanie Kortig</span>
                  <FaAngleDown style={{ color: "var(--secondaryText)" }} />
                </div>
                {/* <Switch
                  checkedChildren={<MdLightMode />}
                  unCheckedChildren={<MdOutlineLightMode />}
                  defaultChecked={mode === "dark" ? true : false}
                  onChange={(value) => dispatch(changeValue())}
                /> */}
                {/* <Button
                  icon={<LogoutOutlined />}
                  shape="circle"
                  onClick={() => {
                    history.push("/login");
                  }}
                ></Button> */}

                {/* <div className="profile">
                  <div>
                    <p>John Doe</p>
                    <p>Admin</p>
                  </div>
                </div>*/}
              </div>
            </div>
          </Header>
          <Content
            className="children"
            style={{
              padding: "0 20px",
              margin: "48px 0",
              // padding: 24,
              // minHeight: 280,
            }}
          >
            {children}
          </Content>
          {/* <Footer style={{ textAlign: "center", background: "transparent" }}>
            <p>© 2022 9Q Hub All Rights Reserved.</p>
            <p>Privacy & Security | Terms and Conditons</p>
          </Footer> */}
        </Layout>
      </Layout>
    </div>
  );
};

export default VerticalLayout;
