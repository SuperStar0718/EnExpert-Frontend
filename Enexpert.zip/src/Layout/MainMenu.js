import { UsergroupAddOutlined } from "@ant-design/icons";
import {
  AiOutlineHome,
  HiOutlineStatusOnline,
  AiOutlineBarChart,
  AiOutlineFire,
  BiLineChart,
  FiSettings,
} from "react-icons/all";
import { Menu, Typography, Select } from "antd";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { useState, useEffect } from "react";

const MainMenu = ({ active }) => {
  const { Option } = Select;
  const [openKeys, setOpenKeys] = useState(["notification", "settings"]);
  const { SubMenu } = Menu;
  const history = useHistory();
  useEffect(() => {
    // if (!collapsed) {
    // setOpenKeys([active]);
    // }
  }, [active]);
  const onOpenChange = (items) => {
    console.log(items);
    if (items.includes("notification")) {
      const index = items.indexOf("notification");
      setOpenKeys((prev) => prev.splice(index, 1));
    } else if (items.includes("settings")) {
      const index = items.indexOf("settings");
      setOpenKeys((prev) => prev.splice(index, 1));
    }
  };
  function handleChange(value) {
    console.log(`selected ${value}`);
  }
  return (
    <div>
      <Menu
        mode="inline"
        defaultSelectedKeys={active}
        style={{
          height: "100vh",
          background: "var(--lightBackground)",
          padding: "10px 10px 10px 0",
        }}
      >
        <Menu.Item
          key="dashboard"
          icon={<AiOutlineHome className="icon-size-22" />}
          onClick={() => history.push("/")}
        >
          Dashboard
        </Menu.Item>
        <Menu.Item
          key="live"
          icon={<HiOutlineStatusOnline className="icon-size-22" />}
          onClick={() => history.push("/live")}
        >
          Live
        </Menu.Item>
        <Menu.Item
          key="Analysis"
          icon={<AiOutlineBarChart className="icon-size-22" />}
          onClick={() => history.push("/analysis")}
        >
          Analysis
        </Menu.Item>
        <Menu.Item
          key="energy-production"
          icon={<AiOutlineFire className="icon-size-22" />}
        >
          <Link to={"/energy-production"}>Energy Production</Link>
        </Menu.Item>
        <Menu.Item
          key="load-peak"
          icon={<BiLineChart className="icon-size-22" />}
        >
          <Link to={"/load-peak"}>Load Peak</Link>
        </Menu.Item>
        <Menu.Item
          key="settings"
          icon={<FiSettings className="icon-size-22" />}
        >
          <Link to={"/settings"}>Settings</Link>
        </Menu.Item>
      </Menu>
    </div>
  );
};

export default MainMenu;
