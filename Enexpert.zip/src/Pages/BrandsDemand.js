import { CloseOutlined } from "@ant-design/icons";
import {
  Row,
  Col,
  Typography,
  Button,
  Checkbox,
  Input,
  Divider,
  Form,
  Modal,
  Tag,
  message,
  Upload,
} from "antd";
import moment from "moment";
import { UploadOutlined } from "@ant-design/icons";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Layout from "../Layout/Layout";
import { getAlphabetically, importCsvBrand, createBrand } from "../redux";

const Home = () => {
  const dispatch = useDispatch();
  const [defaultSelectedValues, setDefaultSelectedValues] = useState([]);
  const [alphabet, setAlpha] = useState("A");
  const [loading, setLoading] = useState(false);
  const [selectedValues, setSelectedValues] = useState(
    defaultSelectedValues ? defaultSelectedValues : []
  );
  const [form] = Form.useForm();
  const [formcsv] = Form.useForm();

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [csvModalVisible, setCsvIsModalVisible] = useState(false);
  const brands = useSelector((state) => state.brandReducer.alphabeticalBrands);
  useEffect(() => {
    dispatch(getAlphabetically(alphabet));
  }, [alphabet]);

  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const handleCsvCancel = () => {
    setCsvIsModalVisible(false);
  };

  let alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

  const onfinish = async (values) => {
    console.log(values);
  };
  const token = localStorage.getItem("token");
  const getDays = (createdDate) => {
    var datenow = new Date();
    var date2 = new Date(createdDate);
    console.log(datenow);
    console.log(date2);
    // To calculate the time difference of two dates
    var Difference_In_Time = date2.getTime() - datenow.getTime();

    // // To calculate the no. of days between two dates
    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    return Math.abs(Math.ceil(Difference_In_Days));
  };

  const onFinishCsv = async (values) => {
    //
    console.log(values.csv.file.originFileObj);
    setLoading(true);
    const formdata = new FormData();
    formdata.append("brands", values.csv.file.originFileObj);
    await dispatch(importCsvBrand(formdata));
    form.resetFields();
    setLoading(false);
    setIsModalVisible(false);
  };
  const onFinish = async (values) => {
    setLoading(true);
    await dispatch(createBrand(values));
    form.resetFields();
    setLoading(false);
    setIsModalVisible(false);
  };

  const uploadprops = {
    beforeUpload: (file) => {
      const isCsv = file.type === "text/csv";

      if (!isCsv) {
        message.error(`${file.name} is not a csv file`);
      }

      return isCsv || Upload.LIST_IGNORE;
    },
    onChange: (info) => {
      console.log(info.fileList);
    },
  };
  return (
    <>
      <Layout active={"brands"}>
        <div className="brands-main">
          <Row style={{ display: "flex", alignItems: "center" }}>
            <Col lg={16} md={16}>
              {" "}
              <Typography.Title level={3}>Brands in Demand</Typography.Title>
            </Col>
            <Col lg={8} md={8}>
              {" "}
              <p style={{ display: "flex", justifyContent: "end" }}>
                <Button
                  type="primary"
                  className="squared-btn"
                  onClick={() => setIsModalVisible(true)}
                >
                  Add Brand
                </Button>
                <Button
                  type="primary"
                  className="squared-btn"
                  onClick={() => setCsvIsModalVisible(true)}
                >
                  Import Brands
                </Button>
              </p>
            </Col>
          </Row>
          <div className="category-section">
            <div className="tags">
              {[...alpha].map((element) => {
                return (
                  <span
                    className={element === alphabet ? "selected" : ""}
                    onClick={() => {
                      setAlpha(element);
                    }}
                  >
                    {element}
                  </span>
                );
              })}
            </div>
            <div className="detail-section">
              <div className="head">
                {alphabet}
                <span>Back to Top ^</span>
              </div>
              <Divider />
              <div className="cat-section">
                <Checkbox.Group>
                  <Row>
                    {brands?.map((data) => {
                      return (
                        <Col xs={24} md={12} lg={12}>
                          {data.name}
                        </Col>
                      );
                    })}
                  </Row>
                </Checkbox.Group>
              </div>
            </div>
          </div>
        </div>
      </Layout>
      <Modal
        visible={csvModalVisible}
        centered
        footer={false}
        // closable={false}
        width={"50%"}
        onCancel={handleCsvCancel}
        className="modal-popup"
      >
        <div className="">
          <Typography.Title level={2}>New Product Request</Typography.Title>
          <Form
            layout="vertical"
            form={formcsv}
            className="product-form"
            onFinish={onFinishCsv}
          >
            <Form.Item name="csv" label="CSV">
              <Upload {...uploadprops} maxCount={1} multiple={false}>
                <Button icon={<UploadOutlined />}>Upload csv only</Button>
              </Upload>
            </Form.Item>
            <Form.Item>
              <Button type="primary" loading={loading} htmlType="submit">
                Submit
              </Button>
            </Form.Item>
          </Form>
        </div>
      </Modal>
      <Modal
        visible={isModalVisible}
        centered
        footer={false}
        // closable={false}
        width={"50%"}
        onCancel={handleCancel}
        className="modal-popup"
      >
        <div className="product-main">
          <Typography.Title level={2}>New Brand</Typography.Title>
          <Form
            layout="vertical"
            form={form}
            className="product-form"
            onFinish={onFinish}
          >
            <Form.Item
              name="name"
              label="Product Name"
              rules={[{ required: true, message: "Name is required" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item>
              <Button type="primary" loading={loading} htmlType="submit">
                Submit
              </Button>
            </Form.Item>
          </Form>
        </div>
      </Modal>
    </>
  );
};

export default Home;
