import React, { useEffect, useState } from "react";
import { Row, Col, Typography, Progress, Dropdown, Menu, Space } from "antd";
import { FaArrowDown } from "react-icons/all";
import { DownOutlined } from "@ant-design/icons";
import { useHistory } from "react-router-dom";
import DataTable from "../Components/Table/DataTable";
import Layout from "../Layout/Layout";
import Area from "../Components/charts/Area";
import Column from "../Components/charts/Column";
import { useDispatch, useSelector } from "react-redux";
import { perPage, page } from "../API/index";
import moment from "moment";
import { getHomeStats, getPaginatedTrending } from "../redux/index";
const Home = () => {
  const menu = (
    <Menu
      items={[
        {
          label: <a href="https://www.antgroup.com">1st menu item</a>,
          key: "0",
        },
        {
          label: <a href="https://www.aliyun.com">2nd menu item</a>,
          key: "1",
        },
        {
          type: "divider",
        },
        {
          label: "3rd menu item",
          key: "3",
        },
      ]}
    />
  );

  return (
    <Layout active="dashboard">
      {/* <LoginPopup show /> */}
      <div className="home-main">
        <Row gutter={[10, 16]}>
          <Col md={24} lg={12}>
            <div className="electric-consumption-outer">
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Typography.Title className="title" level={5}>
                  Live Electric Consumption
                </Typography.Title>
              </div>
              <div className="electric-consumption">
                <div className="electric-consumption-left">
                  <Typography.Title className="sub-title" level={4}>
                    304,04 kW
                  </Typography.Title>
                  <div className="percentage-wrapper">
                    <span
                      className="percentage"
                      style={{ color: "var(--green)" }}
                    >
                      {" "}
                      1,3%&nbsp;
                      <FaArrowDown />
                    </span>
                    &nbsp;
                    <span className="text">than last hour</span>
                  </div>
                </div>
                <div className="electric-consumption-right">
                  <div className="percentage-wrapper-left">
                    <p>Spa</p>
                    <p>Hotal</p>
                    <p>Restaurant</p>
                    <p>Laundry</p>
                  </div>
                  {/* <div className="percentage-wrapper-middle"></div> */}
                  <div className="percentage-wrapper-right">
                    <Progress percent={51} />
                    <Progress percent={21} />
                    <Progress percent={18} />
                    <Progress percent={9} />
                  </div>
                </div>
              </div>
            </div>
          </Col>
          <Col md={24} lg={12}>
            <div className="electric-cost-outer">
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Typography.Title className="title" level={5}>
                  Total Energy Cost
                </Typography.Title>
                <Dropdown overlay={menu} trigger={["click"]}>
                  <div onClick={(e) => e.preventDefault()}>
                    <Space>
                      Click me
                      <DownOutlined />
                    </Space>
                  </div>
                </Dropdown>
              </div>
              <div className="electric-cost">
                <div className="electric-cost-left">
                  <Typography.Title className="sub-title" level={4}>
                    306,20 €
                  </Typography.Title>
                  <div className="percentage-wrapper">
                    <span
                      className="percentage"
                      style={{ color: "var(--red)" }}
                    >
                      {" "}
                      5,2%&nbsp;
                      <FaArrowDown />
                    </span>
                    &nbsp;
                    <span className="text">than last day</span>
                  </div>
                </div>
                <div className="electric-cost-right">
                  <div className="item">
                    <Progress type="circle" percent={75} width="100%" />
                    <p>107,17 €</p>
                    <div>
                      <span>Electricity</span>&nbsp;
                      <FaArrowDown />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </div>
    </Layout>
  );
};

export default Home;
