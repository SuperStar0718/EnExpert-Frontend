import React, { useEffect, useState } from "react";
import { Row, Col, Typography, Button, Table, Input } from "antd";
import { useHistory } from "react-router-dom";
import Layout from "../Layout/Layout";
import DataTable from "../Components/Table/DataTable";
import { useDispatch, useSelector } from "react-redux";
import { getPaginatedRequests, deleteRequest } from "../redux/index";
import { perPage, page } from "../API/index";
import moment from "moment";
const Home = () => {
  const history = useHistory();
  const [Data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const [PerPage, setPerPage] = useState(perPage);
  const [searchVal, setSearchVal] = useState("");
  const requests = useSelector((state) => state.requestReducer.requests);
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      dispatch(
        getPaginatedRequests(
          {
            page: page,
            limit: perPage,
            search: searchVal,
          },
          setLoading
        )
      );
      console.log(searchVal);
    }, 1000);
    return () => clearTimeout(timer);
  }, [searchVal]);
  // useEffect(() => {
  //   let tempArr = [];
  //   requests?.docs?.map((data) =>
  //     tempArr.push({
  //       brand: data?.brand?.name,
  //       quantity: data.offerQuantity,
  //       name: data.product.name,
  //       productId: data.product.productCode,
  //       price: data.offerPrice,
  //       desc: data.notes,
  //       action: (
  //         <>
  //           <Button
  //             type="primary"
  //             className="squared-btn squared-secondary"
  //             onClick={async () =>
  //               await dispatch(deleteRequest({ id: data._id }))
  //             }
  //           >
  //             Delete
  //           </Button>
  //         </>
  //       ),
  //     })
  //   );
  //   setData(tempArr);
  // }, [requests]);
  useEffect(() => {
    let tempArr = [];
    requests?.docs?.map((data) =>
      tempArr.push({
        name: data.client.name,
        brand: data.brand.name,
        product: data.product ? data.product.name : "-",
        productId: data.product ? data.product.productCode : "-",
        price: data.offerPrice,
        qty: data.offerQuantity,
        dateTime: moment(data.createdAt).format("YYYY-MM-DD"),
        request: data.offerType,
        action: (
          <>
            <Button
              type="primary"
              className="squared-btn squared-secondary"
              onClick={async () =>
                await dispatch(deleteRequest({ id: data._id }, searchVal))
              }
            >
              Delete
            </Button>
          </>
        ),
      })
    );
    setData(tempArr);
  }, [requests]);

  const columns = [
    {
      title: "Date/Time",
      dataIndex: "dateTime",
      key: "date",
    },
    {
      title: "Client Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Brand",
      dataIndex: "brand",
      key: "age",
    },
    {
      title: "Product",
      dataIndex: "product",
      key: "address",
    },
    {
      title: "Product Id",
      dataIndex: "productId",
      key: "age",
    },
    {
      title: "Price",
      dataIndex: "price",
      key: "price",
    },
    {
      title: "Quantity",
      dataIndex: "qty",
      key: "qty",
    },
    {
      title: "Request",
      dataIndex: "request",
      key: "request",
    },
    {
      title: "Actions",
      dataIndex: "action",
      key: "view",
    },
  ];

  return (
    <Layout active="all">
      {/* <LoginPopup show /> */}
      <div className="buy-sell-main">
        <Typography.Title level={3} style={{ marginTop: "40px" }}>
          Requests
        </Typography.Title>
        <div className="search">
          <p>
            Search{" "}
            <Input
              value={searchVal}
              className="search-input"
              onChange={(e) => setSearchVal(e.target.value)}
            />
          </p>
        </div>
        <DataTable
          bordered={false}
          columns={columns}
          //  setSelectedData={setSelectedData}
          data={Data}
          //pagination
          // Search
          // SearchData={SearchData}
          // setSearchData={setSearchData}
          perPageDefault={PerPage}
          setPerPage={setPerPage}
          defaultPageNo={page}
          setPageNo={async (page, perPage) =>
            await dispatch(
              getPaginatedRequests(
                {
                  page: page,
                  limit: perPage,
                  search: searchVal,
                },
                setLoading
              )
            )
          }
          pageStats={{
            totalItems: requests?.totalDocs,
            currentPage: requests?.page,
          }}
          loader={loading}
        />
      </div>
    </Layout>
  );
};

export default Home;
