import { useState } from "react";
import { Button, Form, Input, Typography, Checkbox } from "antd";
import { useHistory, Redirect, Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { adminLogin } from "../redux/index";

const Login = () => {
  const history = useHistory();

  const dispatch = useDispatch();

  const [loading, setLoading] = useState(false);

  const adminLoginFnc = async (values) => {
    const { email, password } = values;
    setLoading(true);
    // history.replace("/");
    await adminLogin({ email, password }, history);
    setLoading(false);
  };

  if (localStorage.hasOwnProperty("vendorId")) {
    return <Redirect to="/" />;
  } else {
    return (
      <div className="temp-login-main">
        <div className="login-main">
          <Typography.Title level={2}>Welcome!</Typography.Title>
          <p>Sign in to your account to continue</p>
          <Form
            layout="vertical"
            onFinish={adminLoginFnc}
            className="login-form"
          >
            <Form.Item name={"email"} label={"Email"}>
              <Input />
            </Form.Item>
            <Form.Item name={"password"} label={"Password"}>
              <Input type="password" />
            </Form.Item>
            <div className="remember-check">
              <Checkbox>Remember Me</Checkbox>
              <Link>Forgot Password?</Link>
            </div>
            <Form.Item>
              <Button type="primary" loading={loading} htmlType="submit">
                Login
              </Button>
            </Form.Item>
            <div className="signup">
              Don’t have an account?{" "}
              <Link to="/signup">
                <span>Sign up</span>
              </Link>
            </div>
          </Form>
        </div>
      </div>
    );
  }
};

export default Login;
