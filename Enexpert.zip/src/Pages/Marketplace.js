import React, { useEffect, useState } from "react";
import {
  Row,
  Col,
  Modal,
  Form,
  Typography,
  Button,
  Table,
  Input,
  Select,
  Tabs,
  Upload,
  message,
} from "antd";
import { UploadOutlined } from "@ant-design/icons";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import Layout from "../Layout/Layout";
import DataTable from "../Components/Table/DataTable";
import LoginPopup from "../Components/modal/LoginPopup";
import {
  getRequests,
  getAllBrands,
  deleteAllRequests,
  changeRequestStatus,
  createProduct,
  changeSelectedRequestsStatus,
  importCsvProduct,
  changeRequestTrending,
} from "../redux/index";
import { perPage, page } from "../API/index";
const Home = () => {
  const { Option } = Select;
  const [form] = Form.useForm();
  const [formcsv] = Form.useForm();

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [csvModalVisible, setCsvIsModalVisible] = useState(false);
  const [offerStatus, setOfferStatus] = useState("pending");
  const history = useHistory();
  const [PerPage, setPerPage] = useState(perPage);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [searchVal, setSearchVal] = useState("");
  const [ActiveData, setActiveData] = useState(null);
  const [DeletedData, setDeletedData] = useState(null);
  const [PendingdData, setPendingdData] = useState(null);
  const [PublishedData, setPublishedData] = useState(null);
  const [selectedData, setSelectedData] = useState([]);

  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const handleCsvCancel = () => {
    setCsvIsModalVisible(false);
  };
  // const activeRequests = useSelector(
  //   (state) => state.productReducer.activeRequests
  // );
  const {
    activeRequests,
    deletedRequests,
    pendingRequests,
    publishedRequests,
  } = useSelector((state) => state.productReducer);
  const allBrands = useSelector((state) => state.brandReducer.brands);
  useEffect(() => {
    dispatch(getAllBrands());
  }, []);
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      dispatch(
        getRequests(
          {
            page: page,
            limit: PerPage,
            status: offerStatus,
            search: searchVal,
          },
          offerStatus,
          setLoading
        )
      );
      console.log(searchVal);
    }, 1000);
    return () => clearTimeout(timer);
    // } else {
    //   setSearchVal("");
    // }
  }, [searchVal, offerStatus]);
  useEffect(() => {
    console.log(selectedData);
  }, [selectedData]);
  useEffect(() => {
    let tempArr = [];
    activeRequests?.docs?.map((data, index) => {
      tempArr.push({
        key: data?._id,
        name: data.name ? data.name : "-",
        quantity: data.quantity ? data.quantity : "-",
        brand: data.brand.name ? data.brand.name : "-",
        productId: data.productCode ? data.productCode : "-",
        price: data.price ? data.price : "-",
        status: data.status ? data.status : "-",
        action: (
          <>
            <Button
              type="primary"
              className="squared-btn"
              onClick={async () =>
                await dispatch(
                  changeRequestStatus(
                    { id: data._id, status: "published" },
                    offerStatus,
                    searchVal,
                    setLoading
                  )
                )
              }
            >
              Publish
            </Button>
            <Button
              type="primary"
              className="squared-btn squared-secondary"
              onClick={async () =>
                await dispatch(
                  changeRequestStatus(
                    { id: data._id, status: "deleted" },
                    offerStatus,
                    searchVal,
                    setLoading
                  )
                )
              }
            >
              Delete
            </Button>
          </>
        ),
      });
    });
    setActiveData(tempArr);
    // useEffect(() => {});
  }, [activeRequests]);
  useEffect(() => {
    let tempArr = [];
    deletedRequests?.docs?.map((data, index) => {
      tempArr.push({
        key: data?._id,
        name: data.name ? data.name : "-",
        quantity: data.quantity ? data.quantity : "-",
        brand: data.brand.name ? data.brand.name : "-",
        productId: data.productCode ? data.productCode : "-",
        price: data.price ? data.price : "-",
        status: data.status ? data.status : "-",
        action: (
          <>
            <Button
              type="primary"
              className="squared-btn"
              onClick={async () =>
                await dispatch(
                  changeRequestStatus(
                    { id: data._id, status: "active" },
                    offerStatus,
                    searchVal,
                    setLoading
                  )
                )
              }
            >
              Accept
            </Button>
            <Button
              type="primary"
              className="squared-btn"
              onClick={async () =>
                await dispatch(
                  changeRequestStatus(
                    { id: data._id, status: "published" },
                    offerStatus,
                    searchVal,
                    setLoading
                  )
                )
              }
            >
              Publish
            </Button>
          </>
        ),
      });
    });
    setDeletedData(tempArr);
    // useEffect(() => {});
  }, [deletedRequests]);
  useEffect(() => {
    let tempArr = [];
    pendingRequests?.docs?.map((data, index) => {
      tempArr.push({
        key: data?._id,
        name: data.name ? data.name : "-",
        quantity: data.quantity ? data.quantity : "-",
        brand: data.brand.name ? data.brand.name : "-",
        productId: data.productCode ? data.productCode : "-",
        price: data.price ? data.price : "-",
        status: data.status ? data.status : "-",
        action: (
          <>
            <Button
              type="primary"
              className="squared-btn"
              onClick={async () =>
                await dispatch(
                  changeRequestStatus(
                    { id: data._id, status: "active" },
                    offerStatus,
                    searchVal,
                    setLoading
                  )
                )
              }
            >
              Accept
            </Button>
            <Button
              type="primary"
              className="squared-btn"
              onClick={async () =>
                await dispatch(
                  changeRequestStatus(
                    { id: data._id, status: "published" },
                    offerStatus,
                    searchVal,
                    setLoading
                  )
                )
              }
            >
              Publish
            </Button>
            <Button
              type="primary"
              className="squared-btn squared-secondary"
              onClick={async () =>
                await dispatch(
                  changeRequestStatus(
                    { id: data._id, status: "deleted" },
                    offerStatus,
                    searchVal,
                    setLoading
                  )
                )
              }
            >
              Delete
            </Button>
          </>
        ),
      });
    });
    setPendingdData(tempArr);
    // useEffect(() => {});
  }, [pendingRequests]);
  useEffect(() => {
    let tempArr = [];
    publishedRequests?.docs?.map((data, index) => {
      tempArr.push({
        key: data?._id,
        name: data.name ? data.name : "-",
        quantity: data.quantity ? data.quantity : "-",
        brand: data.brand.name ? data.brand.name : "-",
        productId: data.productCode ? data.productCode : "-",
        price: data.price ? data.price : "-",
        status: data.status ? data.status : "-",
        action: (
          <>
            <Button
              type="primary"
              className="squared-btn"
              onClick={async () =>
                await dispatch(
                  changeRequestStatus(
                    { id: data._id, status: "active" },
                    offerStatus,
                    searchVal,
                    setLoading
                  )
                )
              }
            >
              Accept
            </Button>
            <Button
              type="primary"
              className="squared-btn squared-secondary"
              onClick={async () =>
                await dispatch(
                  changeRequestStatus(
                    { id: data._id, status: "deleted" },
                    offerStatus,
                    searchVal,
                    setLoading
                  )
                )
              }
            >
              Delete
            </Button>
            {!data.isTrending ? (
              <Button
                type="primary"
                className="squared-btn "
                onClick={async () =>
                  await dispatch(
                    changeRequestTrending(
                      { id: data._id, isTrending: true },
                      offerStatus,
                      searchVal,
                      setLoading
                    )
                  )
                }
              >
                Make It Trend
              </Button>
            ) : (
              <Button
                type="primary"
                className="squared-btn squared-secondary"
                onClick={async () =>
                  await dispatch(
                    changeRequestTrending(
                      { id: data._id, isTrending: false },
                      offerStatus,
                      searchVal,
                      setLoading
                    )
                  )
                }
              >
                Remove From Trend
              </Button>
            )}
          </>
        ),
      });
    });
    setPublishedData(tempArr);
    // useEffect(() => {});
  }, [publishedRequests]);
  // const dataSource = [
  //   {
  //     key: "1",
  //     name: "Mike",
  //     age: 32,
  //     address: "10 Downing Street",
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Buy",
  //     action: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Accept
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Publish
  //         </Button>
  //         <Button type="primary" className="squared-btn squared-secondary">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "2",
  //     name: "John",
  //     age: 42,
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Sell",
  //     address: "10 Downing Street",
  //     action: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Accept
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Publish
  //         </Button>
  //         <Button type="primary" className="squared-btn squared-secondary">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "3",
  //     name: "John",
  //     age: 42,
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Buy",
  //     address: "10 Downing Street",
  //     action: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Accept
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Publish
  //         </Button>
  //         <Button type="primary" className="squared-btn squared-secondary">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "4",
  //     name: "John",
  //     age: 42,
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Buy",
  //     address: "10 Downing Street",
  //     action: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Accept
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Publish
  //         </Button>
  //         <Button type="primary" className="squared-btn squared-secondary">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "5",
  //     name: "John",
  //     age: 42,
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Sell",
  //     address: "10 Downing Street",
  //     action: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Accept
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Publish
  //         </Button>
  //         <Button type="primary" className="squared-btn squared-secondary">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  // ];

  const columns = [
    {
      title: "Brand",
      dataIndex: "brand",
    },
    {
      title: "Qty",
      dataIndex: "quantity",
    },
    {
      title: "Product",
      dataIndex: "name",
    },
    {
      title: "Product Id",
      dataIndex: "productId",
    },
    {
      title: "Status",
      dataIndex: "status",
    },
    {
      title: "Price",
      dataIndex: "price",
    },
    {
      title: "Action",
      dataIndex: "action",
    },
  ];
  const onFinishCsv = async (values) => {
    //
    console.log(values.csv.file.originFileObj);
    setLoading(true);
    const formdata = new FormData();
    formdata.append("product", values.csv.file.originFileObj);
    await dispatch(
      importCsvProduct(formdata, offerStatus, searchVal, setLoading)
    );
    form.resetFields();
    setLoading(false);
    setIsModalVisible(false);
  };
  const onFinish = async (values) => {
    setLoading(true);
    await dispatch(createProduct(values, offerStatus, searchVal, setLoading));
    form.resetFields();
    setLoading(false);
    setIsModalVisible(false);
  };

  const uploadprops = {
    beforeUpload: (file) => {
      const isCsv = file.type === "text/csv";

      if (!isCsv) {
        message.error(`${file.name} is not a csv file`);
      }

      return isCsv || Upload.LIST_IGNORE;
    },
    onChange: (info) => {
      console.log(info.fileList);
    },
  };
  return (
    <Layout active="marketplace">
      {/* <LoginPopup show /> */}
      <div className="buy-sell-main">
        <Row style={{ display: "flex", alignItems: "center" }}>
          <Col lg={16}>
            {" "}
            <Typography.Title level={3} style={{ marginTop: "40px" }}>
              Live Marketplace
            </Typography.Title>
          </Col>
          <Col lg={4}>
            {" "}
            <Button
              type="primary"
              className="squared-btn"
              onClick={() => setIsModalVisible(true)}
            >
              Add Request
            </Button>
          </Col>
          <Col lg={4}>
            {" "}
            <Button
              type="primary"
              className="squared-btn"
              onClick={() => setCsvIsModalVisible(true)}
            >
              Import Requests
            </Button>
          </Col>
        </Row>

        <Tabs
          defaultActiveKey="pending"
          onChange={(e) => {
            console.log(e);
            setSelectedData([]);
            setOfferStatus(e);
            setSearchVal("");
          }}
        >
          <Tabs.TabPane tab={"Pending Requests"} key="pending">
            <div>
              {/* <Typography.Title level={1}>
                {!searchField ? "Current" : "All"} Projects
              </Typography.Title> */}
              <div className="search">
                <div className="Buttons">
                  <Button
                    type="primary"
                    className="squared-btn squared-secondary"
                    onClick={async () =>
                      dispatch(
                        deleteAllRequests(
                          { status: "pending" },
                          offerStatus,
                          searchVal
                        )
                      )
                    }
                  >
                    Delete All
                  </Button>
                  {selectedData.length > 0 && (
                    <>
                      <Button
                        onClick={async () =>
                          dispatch(
                            changeSelectedRequestsStatus({
                              ids: selectedData,
                              status: "deleted",
                            })
                          )
                        }
                        type="primary"
                        className="squared-btn squared-secondary"
                      >
                        Delete Selected
                      </Button>
                      <Button
                        onClick={async () =>
                          dispatch(
                            changeSelectedRequestsStatus({
                              ids: selectedData,
                              status: "active",
                            })
                          )
                        }
                        type="primary"
                        className="squared-btn"
                      >
                        Accept Selected
                      </Button>
                      <Button
                        onClick={async () =>
                          dispatch(
                            changeSelectedRequestsStatus({
                              ids: selectedData,
                              status: "published",
                            })
                          )
                        }
                        type="primary"
                        className="squared-btn"
                      >
                        Publish Selected
                      </Button>
                    </>
                  )}
                  <div>
                    <Button
                      type="primary"
                      className="squared-btn squared-secondary"
                    >
                      Export Request
                    </Button>
                  </div>
                </div>
                <p>
                  Search{" "}
                  <Input
                    value={searchVal}
                    className="search-input"
                    onChange={(e) => setSearchVal(e.target.value)}
                  />
                </p>
              </div>
              <DataTable
                Border
                columns={columns}
                setSelectedData={setSelectedData}
                data={PendingdData}
                //pagination
                // Search
                // SearchData={SearchData}
                // setSearchData={setSearchData}
                perPageDefault={PerPage}
                setPerPage={setPerPage}
                defaultPageNo={page}
                setPageNo={async (page, perPage) => {
                  setLoading(true);
                  dispatch(
                    getRequests(
                      {
                        page: page,
                        limit: PerPage,
                        status: offerStatus,
                        search: searchVal,
                      },
                      offerStatus,
                      setLoading
                    )
                  );
                }}
                pageStats={{
                  totalItems: pendingRequests?.totalDocs,
                  currentPage: pendingRequests?.page,
                }}
                loader={loading}
              />
            </div>
          </Tabs.TabPane>
          <Tabs.TabPane tab={"Published Requests"} key="published">
            <div>
              {/* <Typography.Title level={1}>
                {!searchField ? "Current" : "All"} Projects
              </Typography.Title> */}
              <div className="search">
                <div className="Buttons">
                  <Button
                    type="primary"
                    className="squared-btn squared-secondary"
                    onClick={async () =>
                      dispatch(
                        deleteAllRequests(
                          { status: "published" },
                          offerStatus,
                          searchVal
                        )
                      )
                    }
                  >
                    Delete All
                  </Button>
                  {selectedData.length > 0 && (
                    <>
                      <Button
                        onClick={async () =>
                          dispatch(
                            changeSelectedRequestsStatus({
                              ids: selectedData,
                              status: "deleted",
                            })
                          )
                        }
                        type="primary"
                        className="squared-btn squared-secondary"
                      >
                        Delete Selected
                      </Button>
                      <Button
                        onClick={async () =>
                          dispatch(
                            changeSelectedRequestsStatus({
                              ids: selectedData,
                              status: "active",
                            })
                          )
                        }
                        type="primary"
                        className="squared-btn"
                      >
                        Accept Selected
                      </Button>
                    </>
                  )}
                  <div>
                    <Button
                      type="primary"
                      className="squared-btn squared-secondary"
                    >
                      Export Request
                    </Button>
                  </div>
                </div>
                <p>
                  Search{" "}
                  <Input
                    value={searchVal}
                    className="search-input"
                    onChange={(e) => setSearchVal(e.target.value)}
                  />
                </p>
              </div>
              <DataTable
                Border
                columns={columns}
                setSelectedData={setSelectedData}
                data={PublishedData}
                //pagination
                // Search
                // SearchData={SearchData}
                // setSearchData={setSearchData}
                perPageDefault={PerPage}
                setPerPage={setPerPage}
                defaultPageNo={page}
                setPageNo={async (page, perPage) => {
                  setLoading(true);
                  dispatch(
                    getRequests(
                      {
                        page: page,
                        limit: PerPage,
                        status: offerStatus,
                        search: searchVal,
                      },
                      offerStatus,
                      setLoading
                    )
                  );
                }}
                pageStats={{
                  totalItems: publishedRequests?.totalDocs,
                  currentPage: publishedRequests?.page,
                }}
                loader={loading}
              />
            </div>
          </Tabs.TabPane>
          <Tabs.TabPane tab={"Active Requests"} key="active">
            <div>
              {/* <Typography.Title level={1}>
                {!searchField ? "Current" : "All"} Projects
              </Typography.Title> */}
              <div className="search">
                <div className="Buttons">
                  <Button
                    type="primary"
                    className="squared-btn squared-secondary"
                    onClick={async () =>
                      dispatch(
                        deleteAllRequests(
                          { status: "active" },
                          offerStatus,
                          searchVal
                        )
                      )
                    }
                  >
                    Delete All
                  </Button>
                  {selectedData.length > 0 && (
                    <>
                      <Button
                        onClick={async () =>
                          dispatch(
                            changeSelectedRequestsStatus({
                              ids: selectedData,
                              status: "deleted",
                            })
                          )
                        }
                        type="primary"
                        className="squared-btn squared-secondary"
                      >
                        Delete Selected
                      </Button>

                      <Button
                        onClick={async () =>
                          dispatch(
                            changeSelectedRequestsStatus({
                              ids: selectedData,
                              status: "published",
                            })
                          )
                        }
                        type="primary"
                        className="squared-btn"
                      >
                        Publish Selected
                      </Button>
                    </>
                  )}
                  <div>
                    <Button
                      type="primary"
                      className="squared-btn squared-secondary"
                    >
                      Export Request
                    </Button>
                  </div>
                </div>
                <p>
                  Search{" "}
                  <Input
                    value={searchVal}
                    className="search-input"
                    onChange={(e) => setSearchVal(e.target.value)}
                  />
                </p>
              </div>
              <DataTable
                Border
                columns={columns}
                setSelectedData={setSelectedData}
                data={ActiveData}
                //pagination
                // Search
                // SearchData={SearchData}
                // setSearchData={setSearchData}
                perPageDefault={PerPage}
                setPerPage={setPerPage}
                defaultPageNo={page}
                setPageNo={(page, perPage) => {
                  setLoading(true);
                  dispatch(
                    getRequests(
                      {
                        page: page,
                        limit: PerPage,
                        status: offerStatus,
                        search: searchVal,
                      },
                      offerStatus,
                      setLoading
                    )
                  );
                }}
                pageStats={{
                  totalItems: activeRequests?.totalDocs,
                  currentPage: activeRequests?.page,
                }}
                loader={loading}
              />
            </div>
          </Tabs.TabPane>
          <Tabs.TabPane tab={"Deleted Requests"} key="deleted">
            <div>
              {/* <Typography.Title level={1}>
                  {!searchField ? "Current" : "All"} Projects
                </Typography.Title> */}
              {selectedData.length > 0 && (
                <>
                  <Button
                    onClick={async () =>
                      dispatch(
                        changeSelectedRequestsStatus({
                          ids: selectedData,
                          status: "active",
                        })
                      )
                    }
                    type="primary"
                    className="squared-btn"
                  >
                    Accept Selected
                  </Button>
                  <Button
                    onClick={async () =>
                      dispatch(
                        changeSelectedRequestsStatus({
                          ids: selectedData,
                          status: "published",
                        })
                      )
                    }
                    type="primary"
                    className="squared-btn"
                  >
                    Publish Selected
                  </Button>
                </>
              )}
            </div>
            <DataTable
              Border
              columns={columns}
              setSelectedData={setSelectedData}
              data={DeletedData}
              //pagination
              // Search
              // SearchData={SearchData}
              // setSearchData={setSearchData}
              perPageDefault={PerPage}
              setPerPage={setPerPage}
              defaultPageNo={page}
              setPageNo={async (page, perPage) => {
                setLoading(true);
                dispatch(
                  getRequests(
                    {
                      page: page,
                      limit: PerPage,
                      status: offerStatus,
                      search: searchVal,
                    },
                    offerStatus,
                    setLoading
                  )
                );
              }}
              pageStats={{
                totalItems: deletedRequests?.totalDocs,
                currentPage: deletedRequests?.page,
              }}
              loader={loading}
            />
          </Tabs.TabPane>
        </Tabs>
      </div>
      <Modal
        visible={csvModalVisible}
        centered
        footer={false}
        // closable={false}
        width={"50%"}
        onCancel={handleCsvCancel}
        className="modal-popup"
      >
        <div className="product-main">
          <Typography.Title level={2}>New Product Request</Typography.Title>
          <Form
            layout="vertical"
            form={formcsv}
            className="product-form"
            onFinish={onFinishCsv}
          >
            <Form.Item name="csv" label="CSV">
              <Upload {...uploadprops} maxCount={1} multiple={false}>
                <Button icon={<UploadOutlined />}>Upload csv only</Button>
              </Upload>
            </Form.Item>
            <Form.Item>
              <Button type="primary" loading={loading} htmlType="submit">
                Submit
              </Button>
            </Form.Item>
          </Form>
        </div>
      </Modal>
      <Modal
        visible={isModalVisible}
        centered
        footer={false}
        // closable={false}
        width={"50%"}
        onCancel={handleCancel}
        className="modal-popup"
      >
        <div className="product-main">
          <Typography.Title level={2}>New Product Request</Typography.Title>
          <Form
            layout="vertical"
            form={form}
            className="product-form"
            onFinish={onFinish}
          >
            <Form.Item
              name="name"
              label="Product Name"
              rules={[{ required: true, message: "Name is required" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="productCode"
              label="Product Code"
              rules={[{ required: true, message: "Product Code is required" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="quantity"
              label="Quantity"
              rules={[{ required: true, message: "Quantity is required" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="price"
              label="Price"
              rules={[{ required: true, message: "Price is required" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="brand"
              label="Brand Name"
              rules={[{ required: true, message: "Brand is required" }]}
            >
              <Select>
                {allBrands?.map((brands, index) => (
                  <Option key={index} value={brands._id}>
                    {brands.name}
                  </Option>
                ))}
              </Select>
            </Form.Item>
            <Form.Item
              name="type"
              label="Type (Buy/Sell)"
              rules={[{ required: true, message: "Type is required" }]}
            >
              <Select>
                <Option value="Buy">Buy</Option>
                <Option value="Sell">Sell</Option>
              </Select>
            </Form.Item>
            <Form.Item
              label="Tags (can write Multiple)"
              name="tags"
              // rules={[{ required: true, message: "Folio No is Required" }]}
            >
              <Select mode="tags" style={{ width: "100%" }} />
              {/* <Input /> */}
            </Form.Item>
            <Form.Item name="note" label="Note">
              <Input.TextArea rows={5} style={{ resize: "none" }} />
            </Form.Item>
            <Form.Item>
              <Button type="primary" loading={loading} htmlType="submit">
                Submit
              </Button>
            </Form.Item>
          </Form>
        </div>
      </Modal>
    </Layout>
  );
};

export default Home;
