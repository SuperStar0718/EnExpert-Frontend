import { Row, Col, Typography, Button, Form, Input, Select } from "antd";
import Layout from "../Layout/Layout";
import MarketCard from "../Components/MarketCard";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { getAllBrands, createProduct } from "../redux/index";
import { useHistory } from "react-router-dom";

const { Option } = Select;

const Home = () => {
  const allBrands = useSelector((state) => state.brandReducer.brands);
  const dispatch = useDispatch();
  const history = useHistory();

  const [loading, setLoading] = useState(false);
  useEffect(() => {
    dispatch(getAllBrands());
  }, []);

  const onFinish = (values) => {
    setLoading(true);
    dispatch(createProduct(values, history));
    setLoading(false);
  };

  return (
    <Layout>
      <div className="product-main">
        <Typography.Title level={2}>New Product Request</Typography.Title>
        <Form layout="vertical" className="product-form" onFinish={onFinish}>
          <Form.Item
            name="name"
            label="Product Name"
            rules={[{ required: true, message: "Name is required" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="productCode"
            label="Product Code"
            rules={[{ required: true, message: "Product Code is required" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="quantity"
            label="Quantity"
            rules={[{ required: true, message: "Quantity is required" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="price"
            label="Price"
            rules={[{ required: true, message: "Price is required" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="brand"
            label="Brand Name"
            rules={[{ required: true, message: "Brand is required" }]}
          >
            <Select>
              {allBrands?.map((brands, index) => (
                <Option key={index} value={brands._id}>
                  {brands.name}
                </Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item
            name="type"
            label="Type (Buy/Sell)"
            rules={[{ required: true, message: "Type is required" }]}
          >
            <Select>
              <Option value="Buy">Buy</Option>
              <Option value="Sell">Sell</Option>
            </Select>
          </Form.Item>
          <Form.Item
            label="Tags (can write Multiple)"
            name="tags"
            // rules={[{ required: true, message: "Folio No is Required" }]}
          >
            <Select mode="tags" style={{ width: "100%" }} />
            {/* <Input /> */}
          </Form.Item>
          <Form.Item name="note" label="Note">
            <Input.TextArea rows={5} style={{ resize: "none" }} />
          </Form.Item>
          <Form.Item>
            <Button type="primary" loading={loading} htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </div>
    </Layout>
  );
};

export default Home;
