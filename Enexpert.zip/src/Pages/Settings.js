import { Button, Col, DatePicker, Form, Input, Row, Typography } from "antd";
import React, { useEffect } from "react";
import Layout from "../Layout/Layout";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import { getAllSettings, updateSettings } from "../redux/index";
import { useDispatch, useSelector } from "react-redux";
const Settings = () => {
  const [form] = Form.useForm();
  const [form2] = Form.useForm();
  const [form3] = Form.useForm();
  const [form4] = Form.useForm();
  const dispatch = useDispatch();
  const {
    numberOfRequests,
    trendingHours,
    cookiePolicy,
    privacyPolicy,
    termsAndConditions,
  } = useSelector((state) => state.settingReducer);

  const UpdateSetting = (values) => {
    console.log(values);
    dispatch(updateSettings(values));
  };

  // const UpdateCookies = (values) => {
  //   dispatch(updateCookiePolicy(values));
  // };
  // const UpdateprivacyPolicy = (values) => {
  //   dispatch(updatePrivacyPolicy(values));
  // };
  useEffect(() => {
    dispatch(getAllSettings());
    form.setFieldsValue({
      numberOfRequests: numberOfRequests,
      trendingHours: trendingHours,
    });
    form2.setFieldsValue({
      cookiePolicy: cookiePolicy,
    });
    form3.setFieldsValue({
      privacyPolicy: privacyPolicy,
    });
    form4.setFieldsValue({
      termsAndConditions: termsAndConditions,
    });
  }, [
    numberOfRequests,
    trendingHours,
    cookiePolicy,
    privacyPolicy,
    termsAndConditions,
  ]);

  return (
    <Layout active="settings">
      <div>
        <Typography.Title
          level={3}
          style={{ marginTop: "40px", marginBottom: "26px" }}
        >
          Trending Managment
        </Typography.Title>

        <Form
          form={form}
          layout="vertical"
          onFinish={UpdateSetting}
          className="login-form"
          initialValues={{}}
        >
          <Row gutter={[20, 20]}>
            <Col xs={24} md={8}>
              <Form.Item
                name="numberOfRequests"
                label="Request Number"
                required
              >
                <Input />
              </Form.Item>
            </Col>
            <Col xs={24} md={8}>
              <Form.Item
                name="trendingHours"
                label="Time Interval (Hours)"
                required
              >
                <Input type="number" style={{ width: "100%" }} />
              </Form.Item>
            </Col>
            <Col xs={24} md={8}>
              <Form.Item label=" ">
                <Button
                  type="primary"
                  htmlType="submit"
                  className="squared-btn small-btn"
                >
                  Save
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>

        <Typography.Title
          level={4}
          style={{ marginTop: "40px", marginBottom: "20px" }}
        >
          Update Cookies Policy
        </Typography.Title>

        <Form
          form={form2}
          layout="vertical"
          onFinish={UpdateSetting}
          className="login-form"
          initialValues={{
            cookiePolicy: cookiePolicy,
          }}
        >
          <Row gutter={[20, 0]}>
            <Col xs={24} md={16}>
              <Form.Item
                label="cookie Policy"
                name="cookiePolicy"
                valuePropName="data"
                getValueFromEvent={(event, editor) => {
                  const data = editor.getData();
                  return data;
                }}
                rules={[{ required: true, message: "Please enter the body" }]}
              >
                <CKEditor editor={ClassicEditor} />
              </Form.Item>
            </Col>
            <Col xs={24} md={8}>
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  className="squared-btn small-btn"
                >
                  Save
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
        <Typography.Title
          level={4}
          style={{ marginTop: "40px", marginBottom: "20px" }}
        >
          Update Privacy Policy
        </Typography.Title>

        <Form
          form={form3}
          layout="vertical"
          onFinish={UpdateSetting}
          className="login-form"
          initialValues={{
            privacyPolicy: privacyPolicy,
          }}
        >
          <Row gutter={[20, 0]}>
            <Col xs={24} md={16}>
              <Form.Item
                name="privacyPolicy"
                label="Privacy Policy"
                valuePropName="data"
                getValueFromEvent={(event, editor) => {
                  const data = editor.getData();
                  return data;
                }}
                rules={[{ required: true, message: "Please enter the body" }]}
              >
                <CKEditor editor={ClassicEditor} />
              </Form.Item>
            </Col>
            <Col xs={24} md={8}>
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  className="squared-btn small-btn"
                >
                  Save
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
        <Typography.Title
          level={4}
          style={{ marginTop: "40px", marginBottom: "20px" }}
        >
          Update Terms And Conditions
        </Typography.Title>

        <Form
          form={form4}
          layout="vertical"
          onFinish={UpdateSetting}
          initialValues={{
            termsAndConditions: termsAndConditions,
          }}
        >
          <Row gutter={[20, 0]}>
            <Col xs={24} md={16}>
              <Form.Item
                name="termsAndConditions"
                label="Terms And Conditions"
                valuePropName="data"
                getValueFromEvent={(event, editor) => {
                  const data = editor.getData();
                  return data;
                }}
                rules={[{ required: true, message: "Please enter the body" }]}
              >
                <CKEditor editor={ClassicEditor} />
              </Form.Item>
            </Col>
            <Col xs={24} md={8}>
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  className="squared-btn small-btn"
                >
                  Save
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </div>
    </Layout>
  );
};

export default Settings;
