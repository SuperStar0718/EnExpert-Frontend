import { useState } from "react";
import { Button, Form, Input, Typography, Checkbox } from "antd";
import { useHistory, Redirect, Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { adminSignup } from "../redux/index";

const Login = () => {
  const history = useHistory();

  const dispatch = useDispatch();

  const [loading, setLoading] = useState(false);

  const adminSignupFunc = async (values) => {
    const { email, password, name } = values;
    setLoading(true);
    // adminSignup({ email, password, name }, history);
    setLoading(false);
  };

  if (localStorage.hasOwnProperty("vendorId")) {
    return <Redirect to="/" />;
  } else {
    return (
      <div className="temp-login-main signup-main">
        <div className="login-main">
          <Typography.Title level={2}>Sign Up!!!</Typography.Title>
          <p>
            Start creating the best possible user experience for you customers
          </p>
          <Form
            layout="vertical"
            onFinish={adminSignupFunc}
            className="login-form"
          >
            <Form.Item name={"name"} label={"Name"}>
              <Input />
            </Form.Item>

            <Form.Item name={"email"} label={"Email Address"}>
              <Input />
            </Form.Item>

            <Form.Item name={"password"} label={"Password"}>
              <Input type="password" />
            </Form.Item>

            <Form.Item>
              <Button type="primary" loading={loading} htmlType="submit">
                Sign Up
              </Button>
            </Form.Item>
            <div className="signup">
              Already have account?{" "}
              <Link to="/login">
                <span>Login</span>
              </Link>
            </div>
          </Form>
        </div>
      </div>
    );
  }
};

export default Login;
