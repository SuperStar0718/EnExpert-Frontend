import React, { useEffect, useState } from "react";
import { Row, Col, Typography, Button, Table, Input } from "antd";
import { useHistory } from "react-router-dom";
import Layout from "../Layout/Layout";
import DataTable from "../Components/Table/DataTable";
import { useDispatch, useSelector } from "react-redux";
import { getPaginatedTrending, changetrendingtatus } from "../redux/index";
import { perPage, page } from "../API/index";
const Home = () => {
  const history = useHistory();
  const [Data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const [searchVal, setSearchVal] = useState("");
  const [PerPage, setPerPage] = useState(perPage);
  const { trending } = useSelector((state) => state.productReducer);
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      dispatch(
        getPaginatedTrending(
          { page: page, limit: perPage, search: searchVal },
          setLoading
        )
      );
      console.log(searchVal);
    }, 1000);

    return () => clearTimeout(timer);
    // } else {
    //   setSearchVal("");
    // }
  }, [searchVal]);
  useEffect(() => {
    let tempArr = [];
    trending?.docs?.map((data, index) => {
      tempArr.push({
        key: data?._id,
        name: data.name ? data.name : "-",
        brand: data.brand.name ? data.brand.name : "-",
        productId: data.productCode ? data.productCode : "-",
        price: data.price ? data.price : "-",
        status: data.status ? data.status : "-",
      });
    });
    setData(tempArr);
    // useEffect(() => {});
  }, [trending]);
  useEffect(() => {
    console.log(Data);
  }, [Data]);
  // const dataSource = [
  //   {
  //     key: "1",
  //     name: "Mike",
  //     age: 32,
  //     address: "10 Downing Street",
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Buy",
  //     view: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Edit
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "2",
  //     name: "John",
  //     age: 42,
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Sell",
  //     address: "10 Downing Street",
  //     view: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Edit
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "3",
  //     name: "John",
  //     age: 42,
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Buy",
  //     address: "10 Downing Street",
  //     view: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Edit
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "4",
  //     name: "John",
  //     age: 42,
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Buy",
  //     address: "10 Downing Street",
  //     view: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Edit
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "5",
  //     name: "John",
  //     age: 42,
  //     price: "€185.00",
  //     date: "12/10/2121, 10:20 PM",
  //     request: "Sell",
  //     address: "10 Downing Street",
  //     view: (
  //       <>
  //         <Button type="primary" className="squared-btn">
  //           Edit
  //         </Button>
  //         <Button type="primary" className="squared-btn">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  // ];

  const columns = [
    {
      title: "Brand",
      dataIndex: "brand",
    },
    {
      title: "Product",
      dataIndex: "name",
    },
    {
      title: "Product Id",
      dataIndex: "productId",
      key: "productId",
    },
    {
      title: "Price",
      dataIndex: "price",
      key: "price",
    },
    // {
    //   title: "",
    //   dataIndex: "view",
    //   key: "view",
    // },
  ];

  return (
    <Layout active="trending">
      {/* <LoginPopup show /> */}
      <div className="buy-sell-main">
        <Typography.Title level={3} style={{ marginTop: "40px" }}>
          Trending
        </Typography.Title>
        <div className="search">
          <p>
            Search{" "}
            <Input
              value={searchVal}
              className="search-input"
              onChange={(e) => setSearchVal(e.target.value)}
            />
          </p>
        </div>
        <DataTable
          bordered={false}
          columns={columns}
          //  setSelectedData={setSelectedData}
          data={Data}
          //pagination
          // Search
          // SearchData={SearchData}
          // setSearchData={setSearchData}
          perPageDefault={PerPage}
          setPerPage={setPerPage}
          defaultPageNo={page}
          setPageNo={async (page, perPage) => {
            setLoading(true);
            dispatch(
              getPaginatedTrending(
                {
                  page: page,
                  limit: perPage,
                  search: searchVal,
                },
                setLoading
              )
            );
          }}
          pageStats={{
            totalItems: trending?.totalDocs,
            currentPage: trending?.page,
          }}
          loader={loading}
        />
      </div>
    </Layout>
  );
};

export default Home;
