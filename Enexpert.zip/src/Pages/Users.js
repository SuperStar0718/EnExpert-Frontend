import React, { useEffect, useState } from "react";
import { Row, Col, Typography, Button, Table, Input } from "antd";
import { useHistory } from "react-router-dom";
import Layout from "../Layout/Layout";
import DataTable from "../Components/Table/DataTable";
import { useDispatch, useSelector } from "react-redux";
import { getPaginatedUsers, changeUserStatus } from "../redux/index";
import { perPage, page } from "../API/index";
const Home = () => {
  const history = useHistory();
  const [Data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const [searchVal, setSearchVal] = useState("");
  const [PerPage, setPerPage] = useState(perPage);
  const { users } = useSelector((state) => state.userReducer);
  const allBrands = useSelector((state) => state.brandReducer.brands);
  // useEffect(() => {
  //   (async () => {
  //     setLoading(true);
  //     await dispatch(getPaginatedUsers({ page: page, limit: perPage }));
  //     setLoading(false);
  //   })();
  // }, []);
  useEffect(() => {
    setLoading(true);

    const timer = setTimeout(() => {
      dispatch(
        getPaginatedUsers(
          {
            page: page,
            limit: perPage,
            search: searchVal,
          },
          setLoading
        )
      );
    }, 1000);

    return () => clearTimeout(timer);
  }, [searchVal]);
  useEffect(() => {
    let tempArr = [];
    users?.docs?.map((data, index) => {
      tempArr.push({
        key: data?._id,
        name: data.name,
        company: data.company,
        email: data.email,
        country: data.country,
        telephone: data.phone,
        date: data.createdAt,
        action: (
          <>
            {data.blocked ? (
              <Button
                type="primary"
                className="squared-btn"
                onClick={async () =>
                  await dispatch(
                    changeUserStatus(
                      { id: data._id, blocked: false },
                      searchVal
                    )
                  )
                }
              >
                Active
              </Button>
            ) : (
              <Button
                type="primary"
                className="squared-btn squared-secondary"
                onClick={async () =>
                  await dispatch(
                    changeUserStatus({ id: data._id, blocked: true }, searchVal)
                  )
                }
              >
                Delete
              </Button>
            )}
          </>
        ),
      });
    });
    setData(tempArr);
    // useEffect(() => {});
  }, [users]);

  // const dataSource = [
  //   {
  //     key: "1",
  //     name: "Jhone aliayn",
  //     company: "BMS",
  //     email: "Jhone @gmail.com",
  //     country: "Austraila",
  //     date: "12/10/2121, 10:20 PM",
  //     telephone: "+923224407380",
  //     view: (
  //       <>
  //         <Button type="primary" className="squared-btn squared-green">
  //           Active
  //         </Button>
  //         <Button type="primary" className="squared-btn squared-secondary">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "1",
  //     name: "Jhone aliayn",
  //     company: "BMS",
  //     email: "Jhone @gmail.com",
  //     country: "Austraila",
  //     date: "12/10/2121, 10:20 PM",
  //     telephone: "+923224407380",
  //     view: <></>,
  //   },
  //   {
  //     key: "1",
  //     name: "Jhone aliayn",
  //     company: "BMS",
  //     email: "Jhone @gmail.com",
  //     country: "Austraila",
  //     date: "12/10/2121, 10:20 PM",
  //     telephone: "+923224407380",
  //     view: (
  //       <>
  //         <Button type="primary" className="squared-btn squared-secondary">
  //           Deactive
  //         </Button>
  //         <Button type="primary" className="squared-btn squared-secondary">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  //   {
  //     key: "1",
  //     name: "Jhone aliayn",
  //     company: "BMS",
  //     email: "Jhone @gmail.com",
  //     country: "Austraila",
  //     date: "12/10/2121, 10:20 PM",
  //     telephone: "+923224407380",
  //     view: (
  //       <>
  //         <Button type="primary" className="squared-btn squared-green">
  //           Active
  //         </Button>
  //         <Button type="primary" className="squared-btn squared-secondary">
  //           Delete
  //         </Button>
  //       </>
  //     ),
  //   },
  // ];

  const columns = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Company",
      dataIndex: "company",
    },
    {
      title: "Email",
      dataIndex: "email",
    },
    {
      title: "Country",
      dataIndex: "country",
    },
    {
      title: "Telephone",
      dataIndex: "telephone",
    },
    {
      title: "Actions",
      dataIndex: "action",
    },
  ];
  return (
    <Layout active="users">
      {/* <LoginPopup show /> */}
      <div className="buy-sell-main">
        <Typography.Title level={3} style={{ marginTop: "40px" }}>
          All Users
        </Typography.Title>
        <div className="search">
          <p>
            Search{" "}
            <Input
              value={searchVal}
              className="search-input"
              onChange={(e) => setSearchVal(e.target.value)}
            />
          </p>
        </div>
        <DataTable
          bordered={false}
          columns={columns}
          //  setSelectedData={setSelectedData}
          data={Data}
          //pagination
          // Search
          // SearchData={SearchData}
          // setSearchData={setSearchData}
          perPageDefault={PerPage}
          setPerPage={setPerPage}
          defaultPageNo={page}
          setPageNo={async (page, perPage) => {
            setLoading(true);
            await dispatch(
              getPaginatedUsers(
                {
                  page: page,
                  limit: perPage,
                  search: searchVal,
                },
                setLoading
              )
            );
          }}
          pageStats={{
            totalItems: users?.totalDocs,
            currentPage: users?.page,
          }}
          loader={loading}
        />
      </div>
    </Layout>
  );
};

export default Home;
