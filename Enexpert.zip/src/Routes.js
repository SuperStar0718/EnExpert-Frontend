import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Home from "./Pages/Home";
import BuySell from "./Pages/BuySell";
import LiveRequest from "./Pages/LiveRequest";
import Marketplace from "./Pages/Marketplace";
import Trending from "./Pages/Trending";
import Users from "./Pages/Users";

import QuoteRequest from "./Pages/QuoteRequest";
import Login from "./Pages/Login";
import Signup from "./Pages/Signup";
import BrandsDemand from "./Pages/BrandsDemand";
import Settings from "./Pages/Settings";
import PrivateRoutes from "./PrivateRoutes";
const Routes = () => {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/buy-sell" exact component={BuySell} />
        <Route path="/live-request" exact component={LiveRequest} />
        <Route path="/marketplace" exact component={Marketplace} />
        <Route path="/add-request" exact component={QuoteRequest} />
        <Route path="/trending" exact component={Trending} />
        <Route path="/users" exact component={Users} />
        <Route path="/brands" exact component={BrandsDemand} />
        <Route path="/login" exact component={Login} />
        {/* <Route path="/signup" exact component={Signup} /> */}
        <PrivateRoutes path="/settings" exact component={Settings} />
      </Switch>
    </Router>
  );
};
export default Routes;
