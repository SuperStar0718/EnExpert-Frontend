export const colors = [
  "#F05454",
  "#264653",
  "#2a9d8f",
  "#e9c46a",
  "#6930c3",
  "#fb8500",
];
export const backgroundColors = ["#222831", "#DADDFC", "#fff", "#f5f5f5"];
