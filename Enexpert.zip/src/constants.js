// const url = `http://localhost:8000`;
// const url = `http://101.53.236.230:8000`;
const url = `https://qhub9-backend.herokuapp.com`;
//  const url = `http://192.168.18.18:8000`;

const limit = 10;

const headers = {
  Authorization: `Bearer ${localStorage.getItem("token")}`,
};

// export { url, headers };
export { url, limit, headers };
