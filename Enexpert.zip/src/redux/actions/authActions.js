import swal from "sweetalert";
import { publicAPI } from "../../API";

export const adminLogin = async (payload, history) => {
  try {
    console.log(payload);
    const res = await publicAPI.post(`/admin/login`, payload);
    if (res) {
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("name", res.data.user.name);

      // localStorage.setItem("role", res.data.user.role);
      swal("", res.data.message, "success").then(() => {
        history.replace("/");
      });
    }
  } catch (err) {
    swal("", err?.response?.data?.message || "Server Error", "error");
  }
};

// export const adminSignup = async (payload, history) => {
//   // return async (dispatch) => {
//   try {
//     const res = await publicAPI.post(`/admin/create`, payload);
//     if (res) {
//       swal("", res.data.message, "success").then(() => {
//         history.replace("/login");
//       });
//     }
//   } catch (err) {
//     swal("", err?.response?.data?.message || "Server Error", "error");
//   }
// };
