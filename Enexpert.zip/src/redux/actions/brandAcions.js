import { notification } from "antd";
import swal from "sweetalert";
import { publicAPI, privateAPI, attachToken } from "../../API";
import { url, limit, headers } from "../../constants";
import * as generalTypes from "../types/generalTypes";
import { perPage, page } from "../../API";

export const getAlphabetically = (alphabet = "A") => {
  return async (dispatch) => {
    try {
      attachToken();
      const res = await publicAPI.get(`/brand/get-alphabetically/${alphabet}`);
      if (res) {
        console.log(res.data);
        dispatch({
          type: generalTypes.GET_ALPHABET_BRANDS,
          payload: res.data,
        });
      }
    } catch (err) {
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};

export const importCsvBrand = (payload) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(`${url}/brand/upload-brands`, payload);
      if (res) {
        console.log(res.data);
        notification.success({
          message: res.data.message,
          duration: 5,
        });
        await dispatch(getAlphabetically());

        // dispatch({
        //   type: generalTypes.GET_PENDING_PRODUCTS_REQUESTS,
        //   payload: res.data,
        // });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const getAllBrands = () => {
  return async (dispatch) => {
    try {
      const res = await publicAPI.get(`/brand/get-all`);
      if (res) {
        dispatch({
          type: generalTypes.GET_ALL_BRANDS,
          payload: res.data,
        });
      }
    } catch (err) {
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const createBrand = (payload) => {
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(`${url}/brand/create-admin`, payload);
      if (res) {
        console.log(res.data);
        notification.success({
          message: res.data.message,
          duration: 5,
        });
        await dispatch(getAlphabetically());
      }
    } catch (err) {
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
