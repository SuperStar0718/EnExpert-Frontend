import { notification } from "antd";
import swal from "sweetalert";
import { publicAPI, privateAPI, attachToken } from "../../API";

export const getHomeStats = () => {
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.get(`/home/get-admin-stats`);
      if (res) {
        console.log(res.data);
        return res.data;
      }
    } catch (err) {
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
