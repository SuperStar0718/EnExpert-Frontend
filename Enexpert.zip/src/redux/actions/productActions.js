import axios from "axios";
import swal from "sweetalert";
import { notification } from "antd";
import { url, limit, headers } from "../../constants";
import { publicAPI, privateAPI, attachToken } from "../../API";
import * as generalTypes from "../types/generalTypes";
import { perPage, page } from "../../API";

export const getRequests = (payload, status = "pending", setLoading) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(`${url}/product/get-requests`, payload);
      setLoading(false);
      if (res) {
        console.log(res.data);
        dispatch({
          type: generalTypes[`GET_${status.toUpperCase()}_PRODUCTS_REQUESTS`],
          payload: res.data,
        });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const createProduct = (
  payload,
  status = "pending",
  search = "",
  setLoading
) => {
  return async (dispatch) => {
    console.log(payload);
    try {
      attachToken();
      const res = await privateAPI.post(`/product/admin-create`, payload);

      if (res) {
        console.log(res.data);
        notification.success({
          message: res.data.message,
          duration: 5,
        });
        await dispatch(
          getRequests(
            { page: page, limit: perPage, status, search },
            status,
            setLoading
          )
        );
        // dispatch({
        //   type: generalTypes.GET_PENDING_PRODUCTS_REQUESTS,
        //   payload: res.data,
        // });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};

export const changeRequestStatus = (
  payload,
  status = "pending",
  search = "",
  setLoading
) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(
        `${url}/product/change-status`,
        payload
      );
      if (res) {
        console.log(res.data);
        notification.success({
          message: res.data.message,
          duration: 5,
        });
        await dispatch(
          getRequests(
            { page: page, limit: perPage, status, search },
            status,
            setLoading
          )
        );
        // await dispatch(getPendingRequests({ page: page, limit: perPage }));
        // await dispatch(getDeletedRequests({ page: page, limit: perPage }));
        // await dispatch(getPublishedRequests({ page: page, limit: perPage }));
        // dispatch({
        //   type: generalTypes.GET_PENDING_PRODUCTS_REQUESTS,
        //   payload: res.data,
        // });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const changeRequestTrending = (
  payload,
  status = "pending",
  search = "",
  setLoading
) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(
        `${url}/product/change-trending`,
        payload
      );
      if (res) {
        console.log(res.data);
        notification.success({
          message: res.data.message,
          duration: 5,
        });
        await dispatch(
          getRequests(
            { page: page, limit: perPage, status, search },
            status,
            setLoading
          )
        );
        // dispatch({
        //   type: generalTypes.GET_PENDING_PRODUCTS_REQUESTS,
        //   payload: res.data,
        // });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const importCsvProduct = (
  payload,
  status = "pending",
  search = "",
  setLoading
) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(
        `${url}/product/upload-products`,
        payload
      );
      if (res) {
        console.log(res.data);
        notification.success({
          message: res.data.message,
          duration: 5,
        });
        await dispatch(
          getRequests(
            { page: page, limit: perPage, status, search },
            status,
            setLoading
          )
        );
        // await dispatch(getPendingRequests({ page: page, limit: perPage }));
        // await dispatch(getDeletedRequests({ page: page, limit: perPage }));
        // await dispatch(getPublishedRequests({ page: page, limit: perPage }));
        // dispatch({
        //   type: generalTypes.GET_PENDING_PRODUCTS_REQUESTS,
        //   payload: res.data,
        // });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const changeSelectedRequestsStatus = (payload) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(
        `${url}/product/change-selected-status`,
        payload
      );
      if (res) {
        console.log(res.data);
        notification.success({
          message: res.data.message,
          duration: 5,
        });
        await dispatch(getRequests({ page: page, limit: perPage }));
        // await dispatch(getPendingRequests({ page: page, limit: perPage }));
        // await dispatch(getDeletedRequests({ page: page, limit: perPage }));
        // await dispatch(getPublishedRequests({ page: page, limit: perPage }));
        // dispatch({
        //   type: generalTypes.GET_PENDING_PRODUCTS_REQUESTS,
        //   payload: res.data,
        // });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const deleteAllRequests = (payload) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(`${url}/product/delete-all`, payload);
      if (res) {
        console.log(res.data);
        await dispatch(getRequests({ page: page, limit: perPage }));
        // await dispatch(getPendingRequests({ page: page, limit: perPage }));
        // await dispatch(getDeletedRequests({ page: page, limit: perPage }));
        // await dispatch(getPublishedRequests({ page: page, limit: perPage }));
        notification.success({
          message: res.data.message,
          duration: 5,
        });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const getPaginatedTrending = (payload, setLoading) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(
        `${url}/product/get-paginated-trending`,
        payload
      );
      setLoading(false);
      if (res) {
        console.log(res.data);
        dispatch({
          type: generalTypes.GET_PAGINATED_TRENDING,
          payload: res.data,
        });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
