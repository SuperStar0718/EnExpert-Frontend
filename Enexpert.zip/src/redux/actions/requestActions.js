import axios from "axios";
import swal from "sweetalert";
import { notification } from "antd";
import { url, limit, headers } from "../../constants";
import { publicAPI, privateAPI, attachToken } from "../../API";
import * as generalTypes from "../types/generalTypes";
import { perPage, page } from "../../API";

export const getPaginatedRequests = (payload, setLoading) => {
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(
        `${url}/offer/get-paginated-requests-admin`,
        payload
      );
      console.log(res.data);
      setLoading(false);
      if (res) {
        dispatch({
          type: generalTypes.GET_PAGINATED_REQUESTS,
          payload: res.data,
        });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const deleteRequest = (payload, search) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(`${url}/offer/delete-request`, payload);
      console.log(res.data);
      if (res) {
        await dispatch(
          getPaginatedRequests({ page: page, limit: perPage, search })
        );
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
