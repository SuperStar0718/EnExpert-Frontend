import { notification } from "antd";
import swal from "sweetalert";
import { publicAPI, privateAPI, attachToken } from "../../API";
import { GET_ALL_SETTINGS } from "../types/generalTypes";

export const getAllSettings = () => {
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.get(`/settings/get-all`);
      if (res) {
        dispatch({
          type: GET_ALL_SETTINGS,
          payload: res.data,
        });
      }
    } catch (err) {
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
export const updateSettings = (payload) => {
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(`/settings/update-settings`, payload);
      if (res) {
        notification.success({
          message: res.data.message,
          duration: 5,
        });
        await dispatch(getAllSettings());
      }
    } catch (err) {
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
// export const updateCookiePolicy = (payload) => {
//   return async (dispatch) => {
//     try {
//       attachToken();
//       const res = await privateAPI.post(
//         `/settings/update-cookie-policy`,
//         payload
//       );
//       if (res) {
//         notification.success({
//           message: res.data.message,
//           duration: 5,
//         });
//         await dispatch(getAllSettings());
//       }
//     } catch (err) {
//       swal("", err?.response?.data?.message || "Server Error", "error");
//     }
//   };
// };
// export const updatePrivacyPolicy = (payload) => {
//   return async (dispatch) => {
//     try {
//       attachToken();
//       const res = await privateAPI.post(
//         `/settings/update-privacy-policy`,
//         payload
//       );
//       if (res) {
//         notification.success({
//           message: res.data.message,
//           duration: 5,
//         });
//         await dispatch(getAllSettings());
//       }
//     } catch (err) {
//       swal("", err?.response?.data?.message || "Server Error", "error");
//     }
//   };
// };
