import axios from "axios";
import swal from "sweetalert";
import { notification } from "antd";
import { url, limit, headers } from "../../constants";
import { publicAPI, privateAPI, attachToken } from "../../API";
import * as generalTypes from "../types/generalTypes";
import { perPage, page } from "../../API";

export const getPaginatedUsers = (payload, setLoading) => {
  console.log(payload);
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(
        `${url}/client/get-all-paginated`,
        payload
      );
      setLoading(false);
      console.log(res.data);
      if (res) {
        dispatch({
          type: generalTypes.GET_ALL_USERS,
          payload: res.data,
        });
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};

export const changeUserStatus = (payload, search) => {
  return async (dispatch) => {
    try {
      attachToken();
      const res = await privateAPI.post(`${url}/client/change-status`, payload);
      if (res) {
        console.log(res.data);
        notification.success({
          message: res.data.message,
          duration: 5,
        });

        await dispatch(
          getPaginatedUsers({ page: page, limit: perPage, search })
        );
      }
    } catch (err) {
      console.log(err);
      swal("", err?.response?.data?.message || "Server Error", "error");
    }
  };
};
