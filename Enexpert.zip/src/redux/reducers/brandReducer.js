import { GET_ALL_BRANDS, GET_ALPHABET_BRANDS } from "../types/generalTypes";

const initialState = {
  brands: null,
  alphabeticalBrands: null,
};

const userReducer = (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case GET_ALL_BRANDS:
      return {
        ...state,
        brands: payload,
      };
    case GET_ALPHABET_BRANDS:
      return {
        ...state,
        alphabeticalBrands: payload,
      };
    default:
      return state;
  }
};

export default userReducer;
