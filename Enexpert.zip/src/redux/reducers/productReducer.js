import {
  GET_DELETED_PRODUCTS_REQUESTS,
  GET_ACTIVE_PRODUCTS_REQUESTS,
  GET_PUBLISHED_PRODUCTS_REQUESTS,
  GET_PENDING_PRODUCTS_REQUESTS,
  GET_PAGINATED_TRENDING,
} from "../types/generalTypes";

const initialState = {
  activeRequests: null,
  publishedRequests: null,
  pendingRequests: null,
  deletedRequests: null,
  trending: null,
};

const productReducer = (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case GET_ACTIVE_PRODUCTS_REQUESTS:
      return {
        ...state,
        activeRequests: payload,
      };
    case GET_PUBLISHED_PRODUCTS_REQUESTS:
      return {
        ...state,
        publishedRequests: payload,
      };
    case GET_PENDING_PRODUCTS_REQUESTS:
      return {
        ...state,
        pendingRequests: payload,
      };
    case GET_DELETED_PRODUCTS_REQUESTS:
      return {
        ...state,
        deletedRequests: payload,
      };
    case GET_PAGINATED_TRENDING:
      return {
        ...state,
        trending: payload,
      };
    default:
      return state;
  }
};

export default productReducer;
