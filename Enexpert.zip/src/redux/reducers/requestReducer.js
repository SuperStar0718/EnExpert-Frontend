import { GET_PAGINATED_REQUESTS } from "../types/generalTypes";

const initialState = {
  requests: null,
};

const requestReducer = (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case GET_PAGINATED_REQUESTS:
      return {
        ...state,
        requests: payload,
      };
    default:
      return state;
  }
};

export default requestReducer;
