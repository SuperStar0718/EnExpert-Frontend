import { GET_ALL_SETTINGS } from "../types/generalTypes";

const initialState = {
  numberOfRequests: null,
  trendingHours: null,
  cookiePolicy: null,
  termsAndConditions: null,
  privacyPolicy: null,
};

const settingReducer = (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case GET_ALL_SETTINGS:
      return {
        ...state,
        ...payload,
      };

    default:
      return state;
  }
};

export default settingReducer;
