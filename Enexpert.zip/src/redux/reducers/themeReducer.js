import * as themeTypes from "../types/themeTypes";

const initialState = {
  updateValues: false,
};

const userReducer = (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case "value":
      let theme = JSON.parse(localStorage.getItem("themeConfig"));
      localStorage.setItem(
        "themeConfig",
        JSON.stringify({
          ...theme,
          mode: theme.mode === "light" ? "dark" : "light",
        })
      );
      return {
        ...state,
        updateValues: !state.updateValues,
      };
    default:
      return state;
  }
};

export default userReducer;
