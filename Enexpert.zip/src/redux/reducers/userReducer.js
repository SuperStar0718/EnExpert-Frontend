import { GET_ALL_USERS } from "../types/generalTypes";

const initialState = {
  users: null,
};

const productReducer = (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case GET_ALL_USERS:
      return {
        ...state,
        users: payload,
      };

    default:
      return state;
  }
};

export default productReducer;
