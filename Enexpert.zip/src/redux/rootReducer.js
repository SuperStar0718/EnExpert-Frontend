import { combineReducers } from "redux";

import themeReducer from "./reducers/themeReducer";
import productReducer from "./reducers/productReducer";
import requestReducer from "./reducers/requestReducer";
import brandReducer from "./reducers/brandReducer";
import settingReducer from "./reducers/settingReducer";
import userReducer from "./reducers/userReducer";

const rootReducer = combineReducers({
  themeReducer,
  productReducer,
  brandReducer,
  settingReducer,
  userReducer,
  requestReducer,
});

export default rootReducer;
